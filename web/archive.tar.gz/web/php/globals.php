<?php
/*************************************************************
* File: globals.php
* Description: This file contains top-level global variables
*	utilized by PHP scripts throughout Boilerplate
*************************************************************/
$site_root = "https://engineering.purdue.edu/ece477/";
?>